#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h> 
#include <stdbool.h>
#include <ctype.h>

int main() {
   time_t t;
   srand((unsigned) time(&t));
   int ran_num = rand() % 2;

    char array[5];
    array[0] = 'a';
    array[1] = 'b';
    array[2] = 'c';
    array[3] = 'd';

    for (int i=0;i<sizeof(array);i++){
        printf("%d: %c\n", i, array[i]);
    }
}