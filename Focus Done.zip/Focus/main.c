//
// Created by Lili on 26/03/2020.
//

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <time.h> 

#include "input_output.h"
#include "game_init.h"


int main() {

    // declaration of the players, the board , end_game boolean and current player
    player players[PLAYERS_NUM];
    square board[BOARD_SIZE][BOARD_SIZE];
    player * current_player;
    bool end_game;

    printf("<*<*<*<*<*<*<*<*<*<*Starting Focus game>*>*>*>*>*>*>*>*>*>*\n\n");

    // Initialization 
    initialize_players(players);
    initialize_board(board);
    print_board(board);

    // Starting Information
    printf("<---> Pay attention to the board state above <---> \n");
    printf("<---> The square coordinates are are [x,y] <---> \n");
    printf("<---> For example with [1,2], x = 1 and y = 2 <---> \n\n");

    // Untill a player wins
    while (end_game == false)
    {
        // Changing current player after a move 
        if (current_player == NULL){
            time_t t;
            srand((unsigned) time(&t));
            int ran_num = rand() % 2;
            current_player = &players[ran_num];
        }
        else{
            if (current_player->player_color == players[0].player_color)
            {
                current_player = &players[1];
            }
            else
            {
                current_player = &players[0];
            }
        }

        // X, Y values for the square the player is making a move from
        int x_value;
        int y_value;

        // This varaible will change to a players color if they win
        // Otherwise it'll be -1
        color board_status = board_state(board);

        // If the board_status is not -1 a player has won 
        if ( board_status != -1)
        {
            if (players[0].player_color == board_status && players[1].pieces_kept == 0)
            {
                printf("\n\n\n<*<*<*<*<*<*<*<*<*<*%s has won the game>*>*>*>*>*>*>*>*>*>*", players[0].name);
                printf("\n\n\n<*<*<*<*<*<*<*<*<*<*Final board status>*>*>*>*>*>*>*>*>*>*");
                print_board(board);
                printf("\n\n<*<*<*<*<*<*<*<*<*<*Final player status>*>*>*>*>*>*>*>*>*>*\n");
                print_player_stats(players);
                end_game = true;
            }
            else if (players[1].player_color == board_status && players[0].pieces_kept == 0)
            {
                printf("\n\n\n\n<*<*<*<*<*<*<*<*<*<*%s has won the game>*>*>*>*>*>*>*>*>*>*", players[1].name);
                printf("\n\n<*<*<*<*<*<*<*<*<*<*Final board status>*>*>*>*>*>*>*>*>*>*");
                print_board(board);
                printf("\n\n<*<*<*<*<*<*<*<*<*<*Final player status>*>*>*>*>*>*>*>*>*>*\n");
                print_player_stats(players);   
                end_game = true;   
            }
            
        }
        else
        {   

            // Printing player stats
            printf("\n--Current Player stats--");
            print_player_stats(players);
            
            if (current_player->pieces_kept > 0)
            {
                if (current_player->pieces_kept == 1)
                {
                    printf("\n\n<---> %s's go - you have %d piece in reserve <--->", current_player->name, current_player->pieces_kept);
                    kept_piece_prompt(board, current_player);
                }
                else
                {
                    printf("\n\n<---> %s's go - you have %d pieces in reserve <--->", current_player->name, current_player->pieces_kept);
                    kept_piece_prompt(board, current_player);
                }
                
                print_board(board);
            }
            else
            {
                printf("\n\n<---> %s it is now your go, choose the piece you want to move. <---> \n\n", current_player->name);


            validate_move(&x_value, &y_value, current_player->player_color, board, current_player);
            selectpieces(x_value, y_value, board[x_value][y_value].num_pieces, board, current_player);
            print_board(board);

            }
        }
    }
    return 0;
}
