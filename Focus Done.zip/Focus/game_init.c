//
// Created by Lili on 26/03/2020.
//

//
// Created by Lili on 24/03/2020.
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h> 
#include <stdbool.h>
#include <ctype.h>

#include "game_init.h"


// Handy function to print current state of a stack
void print_stack(square * stack_to_print);

// Add a piece on top of a stack
void add_top_of_stack(square * stack, color piece_color);

// Pop a piece from the top of the stack
void pop_from_top_of_stack(square * stack);

// Pop a piece from the bottom of the stack
color pop_from_bottom_of_stack(square * stack);


void initialize_players(player players[PLAYERS_NUM]){

    /* Random number generator for random color allocation */ 
    time_t t;
    srand((unsigned) time(&t));
    int ran_num = rand() % 2;

    /* Getting player names */ 
    printf("\n- Enter player 1's name: ");
    scanf("%s", players[0].name);
    printf("- Enter player 2's name: ");
    scanf("%s", players[1].name);

    // Player names cannot be the same
    if (strcmp(players[0].name, players[1].name) == 0){
        printf("** Player names cannot be the same, try again **\n");
        initialize_players(players);
    }
    else
    {
        /* Setting up starting states */ 
        players[0].pieces_captured = 0;
        players[0].pieces_kept = 0;

        players[1].pieces_captured = 0;
        players[1].pieces_kept = 0;

        /* Assigning colors randomly */ 
        if (ran_num == 0)
        {
            players[0].player_color = RED;
            players[1].player_color = GREEN;
        }
        else
        {
            players[1].player_color = RED;
            players[0].player_color = GREEN;
        }
        
        /* Printing player stats */ 
        printf("\n<---> Players %s (%s) and %s (%s) have been intialsed <---> \n", players[0].name, color_as_string(players[0].player_color),  players[1].name, color_as_string(players[1].player_color));
    }
}


/* Returns Players Color String value */ 
const char* color_as_string(int color){
    if ( color == 0){
        return "RED";
    }
    else{
        return "GREEN";
    }
}


// If a square is not otuside the board range
bool valid_square(int x, int y){
    if((x==0 && (y==0 || y==1 || y==6 || y==7)) || (x==1 && (y==0 || y==7)) ||
       (x==6 && (y==0 || y==7)) || (x==7 && (y==0 || y==1 || y==6 || y==7)) || 
       (x < 0 || y < 0) || (x > 7 || y> 7))
       {
           return false;
       }
    else
    {
        return true;
    }

}


// Initiating  function
void validate_move(int *x_value, int *y_value, color current_player_color, square board[BOARD_SIZE][BOARD_SIZE], player * current_player){
    int x, y;
    char char_x[5], char_y[5];

    // Getting an x,y coord for the piece
    printf("- Enter the x coordinates of this piece: ");
    scanf("%s", char_x);
    x = atoi(char_x);

    printf("- Enter the y coordinates of this piece: ");
    scanf("%s", char_y);
    y = atoi(char_y);

    // Making sure coordinates are numbers
    if ( (y == 0 && strcmp(char_y, "0") != 0) || (x == 0 && strcmp(char_x, "0") != 0) )
    {
        printf("\n** You must choose two digits **\n");
        validate_move(x_value, y_value, current_player_color, board, current_player);
    }

    else{
        // Making sure square coords are valid
        if(valid_square(x, y) == false)
            {
                printf("\n** You have choosen [%d, %d] this is not a valid square **\n", x, y);
                printf("** Look at the board and choose a valid piece now... **\n");
                validate_move(x_value, y_value, current_player_color, board, current_player);
            }

        // If move is a number and a valid square
        // Check if the player can move piece i.e owns it and isn't empty 
        else
        {
            if (player_own_stack(current_player_color, board[x][y].stack_head))
            {
                // Return valid move coords
                *x_value = x;
                *y_value = y;   
            }
            else if (board[x][y].num_pieces == 0)
            {
                printf("\n** This is an empty piece, pick another \n**");
                validate_move(x_value, y_value, current_player_color, board, current_player);
            }
            else
            {
                printf("\n** You do not own this piece, pick another \n**");
                validate_move(x_value, y_value, current_player_color, board, current_player);
            }
        }
    }
}


// Function to check if player owns top of stack
bool player_own_stack(color current_player_color, piece * choosen_piece){
    if (choosen_piece != NULL){ 
        if (current_player_color == choosen_piece->p_color){
            return true;
        }
        else{
            return false;
        }
    }
    else{
        return false;
    }
}


// A function to remove pieces of a stack of height > 5
// Also adds these bottom pieces to current players kept/captured pieces
void remove_extra_pieces(square * stack, player * current_player){

    // Max stack height 
    int max_pieces = 5;
    // Number of pieces to remove 
    int remove_count = stack->num_pieces - max_pieces;

    // Keep track of popped color
    color popped_color;

    // remove bottom pieces
    while (remove_count > 0){

        // removes pieces from bottom of stack
        popped_color = pop_from_bottom_of_stack(stack);

        stack->num_pieces -= 1;
        remove_count -= 1;

        // If the bottom pieces are the same as player color add to kept pieces
        // else add them to captured pieces 

        if (popped_color == current_player->player_color){
            current_player->pieces_kept += 1;
        }
        else
        {
            current_player->pieces_captured += 1;
        }
        
    }
}


// Function to edit a square with current players kept pieces
void kept_piece_edit(square board[BOARD_SIZE][BOARD_SIZE], player * current_player){
    int x, y;
    char char_x[5], char_y[5];

    // Getting an x,y coord for the piece
    printf("\n- Enter the x coordinates of your desintation square: ");
    scanf("%s", char_x);
    x = atoi(char_x);

    printf("- Enter the y coordinates of your desintation square: ");
    scanf("%s", char_y);
    y = atoi(char_y);

    // Making sure coordinates are numbers
    if ( (y == 0 && strcmp(char_y, "0") != 0) || (x == 0 && strcmp(char_x, "0") != 0) )
    {
        printf("\n** You must choose two digits **\n");
        kept_piece_edit(board, current_player);
    }

    // If choosen square is valid, add it to the top
    if (valid_square(x, y))
    {
        add_top_of_stack(&board[x][y], current_player->player_color);
        current_player->pieces_kept -= 1;
    }
    else
    {
            printf("\n** You have choosen [%d, %d] this is not a valid square **\n", x, y);
            kept_piece_edit(board, current_player);
    }
    

}

// Function to prompt a player to use a kept piece 
int kept_piece_prompt(square board[BOARD_SIZE][BOARD_SIZE], player * current_player){

        char choice[1];
        printf("\n- Would you like to place a reserved piece? enter 'y' for yes or 'n' for no: ");
        scanf("%1s", choice);

        if (strcmp(choice, "n") == 0){
            return 0;
        }
        else if (strcmp(choice, "y") == 0){
            kept_piece_edit(board, current_player);
            
        }
        else{
            printf("** Pick a valid choice please **\n");
            kept_piece_prompt(board, current_player);
        }
        return 0;
}


void edit_piece(square * change_square, int amount, piece * top_piece, player * current_player){

    bool adding;

    // If adding is false we'll popping (amount) pieces from this changing stack to the
    if (amount < 0 ){
        adding = false;
        amount = amount*-1;
    }
    // If adding is true we'll be adding (amount) pieces from this top_piece stack to the change_square
    else{
        adding = true;
    }


    // Keeping track of a piece in  a stack
    piece * next = top_piece;

    // Array to hold colors for adding later 
    color array[amount];
    // Count of colors
    int count = 0;

    // If we're adding to this change_square
    if (adding)
    {
        while (next && amount > 0){

                // Adding color array
                array[count] = next->p_color;

                // Derementing amount of pieces left to add
                amount -= 1;

                count += 1;

                // Going to next piece in the old stack.. 
                next = next->next;
            }

            // Adding these colors from our array (back-tofront) onto the new stack
            for (int i=0;i<count;i++)
            {
                add_top_of_stack(change_square, array[count-i-1]);
            }
        
        if (change_square->num_pieces > 5){
            remove_extra_pieces(change_square, current_player);
        }
    }
    else
    {
        while (next && amount > 0){
                // Adding to the new stack
                pop_from_top_of_stack(change_square);
                change_square->num_pieces -= 1;

                // Derementing amount of pieces to add
                amount -= 1;

                // Going to next piece in the old stack.. 
                next = next->next;
            }
    }
}


// function to pop a piece from the bottom of the stack and return it's color
color pop_from_bottom_of_stack(square * stack){
    piece * next = stack->stack_head;
    piece * last_piece;
    while (next->next)
    {
        last_piece = next;
        next = next->next;
    }
    last_piece->next = NULL;
    return last_piece->p_color;
}


// Pop piece from the top of the stack
void pop_from_top_of_stack(square * stack){
    stack->stack_head = stack->stack_head->next;
}


// Add to the top of the stack
void add_top_of_stack(square * stack, color piece_color){
    piece * new_piece;
    new_piece = (piece *) malloc (sizeof(piece));
    new_piece->p_color = piece_color;
    new_piece->next = stack->stack_head;
    stack->stack_head = new_piece;
    stack->num_pieces += 1;
}

// Print a stack (Good for testing)
void print_stack(square * stack_to_print){
    piece * next = stack_to_print->stack_head;
    while (next)
    {
        printf("%s\n", color_as_string(next->p_color));
        next = next->next;
    }
}


// Initiating function to move piece(s) from one stack to another
void move_pieces(int x_value, int y_value, int distance, square board[BOARD_SIZE][BOARD_SIZE], player * current_player){

    // I allow players to move a piece x times 'up', 'down', 'left' or 'right' where x <= number of pieces 
    if (distance == 1){
        printf("- You can move this piece 'up', 'down', 'left' or 'right' %d time", distance);
    }
    else{
        printf("- You can move this piece 'up', 'down', 'left' or 'right' %d times", distance);
    }

    int x, y;
    char char_x[5], char_y[5];

    // Getting an x,y coord for the piece
    printf("\n- Enter the x coordinates of your desintation square: ");
    scanf("%s", char_x);
    x = atoi(char_x);

    printf("- Enter the y coordinates of your desintation square: ");
    scanf("%s", char_y);
    y = atoi(char_y);

    // Making sure coordinates are numbers
    if ( (y == 0 && strcmp(char_y, "0") != 0) || (x == 0 && strcmp(char_x, "0") != 0) )
    {
        printf("\n** You must choose two digits **\n");
        move_pieces(x_value, y_value, distance, board, current_player);
    }

    else
    {
    // Get the absolute distance between the stack we're moving from and the desintation
    int abs_distance = abs(x-x_value)+abs(y-y_value);

    // If the desination square is valid and its absolute distance is <= number of pieces (distance) 
    if (valid_square(x_value, y_value) && abs_distance <= distance && abs_distance != 0)
        {
            // Edit Finish Piece first with new pieces 
            edit_piece(&board[x][y], distance, board[x_value][y_value].stack_head, current_player);
            // Pop old pieces off original square
            edit_piece(&board[x_value][y_value], 0-distance, board[x_value][y_value].stack_head, current_player);
        }

    else if (valid_square(x_value, y_value) && (abs_distance > distance || abs_distance == 0))
        {
            printf("\n** You must move %d square(s), you tried to move %d **\n", distance, abs_distance);
            move_pieces(x_value, y_value, distance, board, current_player);
        }
        else
        {
            printf("\n** You have choosen [%d, %d] this is not a valid square **\n", x_value, y_value);
            move_pieces(x_value, y_value, distance, board, current_player);
        }
    }
}


// function for a player to select either the top piece or the whole stack to move
void selectpieces(int x_value, int y_value, int num_pieces, square board[BOARD_SIZE][BOARD_SIZE] , player * current_player){
    char choice[3];

    if (num_pieces > 1)
    {
        printf("\nStack at [%d, %d] has %d pieces\n", x_value, y_value, num_pieces);
        printf("Enter 'one' to move the top piece or 'all' to move the whole stack: ");
        scanf("%3s", choice);
        if (strcmp(choice, "all") == 0){
            move_pieces(x_value, y_value, num_pieces, board, current_player);
        }
        else if (strcmp(choice, "one") == 0){
            move_pieces(x_value, y_value, 1, board, current_player);
        }
        else{
            printf("Pick a valid choice please...\n");
            selectpieces(x_value, y_value, num_pieces, board, current_player);
        }
    }
    else
    {
        printf("\nStack at [%d, %d] has %d piece\n\n", x_value, y_value, num_pieces);
        move_pieces(x_value, y_value, 1, board, current_player);
    }
    
}

//Set Invalid Squares (where it is not possible to place stacks)
void set_invalid(square * s){
s->type = INVALID;
s->stack_head = NULL;
s->num_pieces = 0;
}

//Set Empty Squares (with no pieces/stacks)
void set_empty(square * s){
s->type = VALID;
s->stack_head = NULL;
s->num_pieces = 0;
}

//Set squares  with a GREEN piece
void set_green(square * s){
s->type = VALID;
s->stack_head = (piece *) malloc (sizeof(piece));
s->stack_head->p_color = GREEN;
s->stack_head->next = NULL;
s->num_pieces = 1;
}

//Set squares with a RED piece
void set_red(square * s){
s->type = VALID;
s->stack_head = (piece *) malloc (sizeof(piece));
s->stack_head->p_color = RED;
s->stack_head->next = NULL;
s->num_pieces = 1;
}

//initializes the board
void initialize_board(square board [BOARD_SIZE][BOARD_SIZE]){

    for(int i=0; i< BOARD_SIZE; i++){
        for(int j=0; j< BOARD_SIZE; j++){
            //invalid squares
            if((i==0 && (j==0 || j==1 || j==6 || j==7)) ||
               (i==1 && (j==0 || j==7)) ||
               (i==6 && (j==0 || j==7)) ||
               (i==7 && (j==0 || j==1 || j==6 || j==7)))
                set_invalid(&board[i][j]);

            else{
                //squares with no pieces
                if(i==0 || i ==7 || j==0 || j == 7)
                    set_empty(&board[i][j]);
                else{
                    //squares with red pieces
                    if((i%2 == 1 && (j < 3 || j> 4)) ||
                       (i%2 == 0 && (j == 3 || j==4)))
                        set_red(&board[i][j]);
                        //green squares
                    else set_green(&board[i][j]);
                }
            }
        }


    }


}

//look for end game situation
color board_state(square board [BOARD_SIZE][BOARD_SIZE]){

    int red_count =0;
    int green_count = 0;

    for(int i=0; i< BOARD_SIZE; i++){
        for(int j=0; j< BOARD_SIZE; j++){
            //invalid squares
            if((i==0 && (j==0 || j==1 || j==6 || j==7)) ||
               (i==1 && (j==0 || j==7)) ||
               (i==6 && (j==0 || j==7)) ||
               (i==7 && (j==0 || j==1 || j==6 || j==7)))
                set_invalid(&board[i][j]);

            else
            {
                if (board[i][j].stack_head)
                {
                    if (board[i][j].stack_head->p_color == RED)
                    {
                        red_count += 1;
                    }
                    else
                    {
                        green_count += 1;
                    }
                    
                }
            }            
        }
    }
    
    if (green_count == 0)
        {
            return RED;
        }
    
    else if (red_count == 0)
        {
            return GREEN;
        }
    else
        {
            return -1;
        }
}

